 package com.authentification.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.authentification.model.UserDTO;

@RestController
@RequestMapping("/auth")
public class AuthenRestCtr {
	@Autowired
	private AuthenService AutServ;
	
	
	
	@RequestMapping(method=RequestMethod.GET,value="/login")
	public boolean getUser(@RequestParam String username, @RequestParam String mdp) {
		ResponseEntity<UserDTO> resp = new RestTemplate().getForEntity("http://localhost:8083/user/"+username+"/getusermdp", UserDTO.class);//le DTO permet de filtrer les infos en trop, ici on veut que username et mdp
		UserDTO dto = resp.getBody();
		String password = dto.getMdp();
		String Username = dto.getUsername();
		System.out.println(username +  "    " + username);
		//User u = AutServ.findUserByUsername(pseudo); //on recupère l'utilisateur a l'aide du pseudo
		boolean conection = AutServ.Connection(Username, username); // on stock le resultat de la tentative de conection
		System.out.println(conection);
		return conection;
		
	}

	
}

