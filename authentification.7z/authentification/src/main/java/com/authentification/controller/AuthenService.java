package com.authentification.controller;


import org.springframework.stereotype.Service;

//import com.atelier.atelier2.model.User;
//import com.atelier.atelier2.repository.UserRepository;

@Service
public class AuthenService {
	
	/*
	public User findUserByUsername(String username) { 	//peut etre voir avec l'id si le temps
		List<User> user= userRes.findByUsername(username);
		User u;
		if (user.size()==1) {
			u = user.get(0);	//return l'user voulu
		}
		else { u = null;}
		return u;
	}
	*/

		
	public  boolean Connection(String username,String pseudo) {
		boolean ret = false;
		if(username.contentEquals(pseudo) ) { //on verifie que le pseudo et le mdp sont ok
			ret = true;
		}
		return ret;
	}
}
