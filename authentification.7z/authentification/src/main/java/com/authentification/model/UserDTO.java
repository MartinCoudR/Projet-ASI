package com.authentification.model;

public class UserDTO {
	private String username;
	private String mdp;
	
	public UserDTO() {

	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getMdp() {
		return mdp;
	}
	public void setPassword(String mdp) {
		this.mdp = mdp;
	}
}